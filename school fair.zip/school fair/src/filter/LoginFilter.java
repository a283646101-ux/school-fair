package filter;

import bean.User;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.net.URLEncoder;

/**
 * 登录验证过滤器
 * 拦截所有请求，除了登录、注册、静态资源
 */
@WebFilter(filterName = "LoginFilter", urlPatterns = {"/*"})
public class LoginFilter implements Filter {

    private static final String[] EXCLUDE_PATHS = {
            "/index.jsp",      // 放行主页
            "/",               // 放行根路径
            "/login.jsp",
            "/login",
            "/register.jsp",
            "/register",
            "/css/",
            "/static/",
            "/bootstrap5.0.1/",
            "/cart?action=add"  // 允许未登录添加商品（可选）
    };

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        HttpSession session = req.getSession(false);

        String path = req.getRequestURI();
        String queryString = req.getQueryString();
        if (queryString != null) {
            path += "?" + queryString;
        }

        // 判断是否需要拦截
        boolean isExcluded = false;
        for (String excludePath : EXCLUDE_PATHS) {
            if (path.contains(excludePath)) {
                isExcluded = true;
                break;
            }
        }

        // 如果是静态资源或登录相关页面，直接放行
        if (isExcluded || path.endsWith(".css") || path.endsWith(".js") || path.endsWith(".jpg") || path.endsWith(".png")) {
            chain.doFilter(request, response);
            return;
        }

        // 检查登录状态
        User user = (session != null) ? (User) session.getAttribute("user") : null;
        if (user != null) {
            // 已登录，放行
            chain.doFilter(request, response);
        } else {
            // 未登录，重定向到登录页
            resp.sendRedirect(req.getContextPath() + "/login.jsp?redirect=" + URLEncoder.encode(path, "UTF-8"));
        }
    }
}
