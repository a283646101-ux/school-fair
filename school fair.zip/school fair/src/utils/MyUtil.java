package utils;

import jakarta.servlet.http.Part;
import java.sql.*;

/**
 * 数据库工具类
 * 提供数据库连接、资源关闭等常用方法
 */
public class MyUtil {
    // 数据库连接参数（已验证通过）
    public static final String url = "jdbc:mysql://localhost:3306/mall?useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai";
    public static final String username = "root";
    public static final String password = "root";

    public static String getFileName(Part part) {
        if (part == null) {
            System.err.println(" Part对象为null");
            return "";
        }
        try {
            String fileName = part.getSubmittedFileName();
            if (fileName != null && !fileName.isEmpty()) {
                return fileName;
            }
            String header = part.getHeader("content-disposition");
            if (header == null || header.isEmpty()) {
                System.err.println("⚠<️ Content-Disposition头为空");
                return "";
            }
            for (String token : header.split(";")) {
                token = token.trim();
                if (token.startsWith("filename")) {
                    // 支持带引号和不带引号的情况
                    String name = token.substring(token.indexOf('=') + 1).trim();
                    // 移除可能的双引号
                    if (name.startsWith("\"") && name.endsWith("\"")) {
                        name = name.substring(1, name.length() - 1);
                    }
                    // 只返回文件名，不包含路径（防止路径遍历攻击）
                    return name.substring(name.lastIndexOf('/') + 1)
                            .substring(name.lastIndexOf('\\') + 1);
                }
            }
        } catch (Exception e) {
            System.err.println(" 解析文件名失败: " + e.getMessage());
            e.printStackTrace();
        }

        return "";
    }

    /**
     * 获取数据库连接
     * @return Connection对象
     * @throws SQLException 如果连接失败
     */
    public static Connection getConnection() throws SQLException {
        try {
            // 显式加载驱动（保险起见）
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println(" MySQL驱动未找到！请检查WEB-INF/lib下是否有mysql-connector-j.jar");
            throw new SQLException("MySQL驱动未加载", e);
        }
        return DriverManager.getConnection(url, username, password);
    }

    /**
     * 关闭Connection资源
     */
    public static void close(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                System.err.println(" 关闭Connection失败: " + e.getMessage());
            }
        }
    }

    /**
     * 关闭Statement资源
     */
    public static void close(Statement stmt) {
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                System.err.println(" 关闭Statement失败: " + e.getMessage());
            }
        }
    }

    /**
     * 关闭ResultSet资源
     */
    public static void close(ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                System.err.println(" 关闭ResultSet失败: " + e.getMessage());
            }
        }
    }

    /**
     * 统一关闭所有数据库资源
     */
    public static void close(Connection conn, Statement stmt, ResultSet rs) {
        close(rs);
        close(stmt);
        close(conn);
    }

    /**
     * 测试数据库连接
     * @return true-连接成功，false-连接失败
     */
    public static boolean testConnection() {
        Connection conn = null;
        try {
            conn = getConnection();
            if (conn != null && !conn.isClosed()) {
                System.out.println(" 数据库连接成功！");
                System.out.println("数据库版本: " + conn.getMetaData().getDatabaseProductVersion());
                System.out.println("驱动版本: " + conn.getMetaData().getDriverVersion());
                return true;
            }
        } catch (SQLException e) {
            System.err.println(" 数据库连接失败！");
            System.err.println("错误信息: " + e.getMessage());
            System.err.println("错误码: " + e.getErrorCode());
            System.err.println("SQL状态: " + e.getSQLState());

            // 常见错误提示
            if (e.getMessage().contains("No suitable driver")) {
                System.err.println(" 提示：请检查WEB-INF/lib下是否有mysql-connector-j-8.x.jar");
            } else if (e.getMessage().contains(" CommunicationsException")) {
                System.err.println(" 提示：请检查MySQL服务是否启动，端口是否为3306");
            } else if (e.getMessage().contains("Access denied")) {
                System.err.println(" 提示：请检查用户名和密码是否正确");
            } else if (e.getMessage().contains("mall")) {
                System.err.println(" 提示：请检查mall数据库是否存在");
            }
        } finally {
            close(conn);
        }
        return false;
    }
}
