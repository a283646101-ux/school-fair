package servlet;

import bean.User;
import utils.MyUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/profile")
public class ProfileServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        User user = (User) request.getSession().getAttribute("user");
        if (user == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String action = request.getParameter("action");
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = MyUtil.getConnection();

            if ("updateEmail".equals(action)) {
                String email = request.getParameter("email");
                String sql = "UPDATE users SET email = ? WHERE id = ?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, email);
                pstmt.setInt(2, user.getId());
                pstmt.executeUpdate();

                request.setAttribute("message", "邮箱修改成功！");

            } else if ("updatePassword".equals(action)) {
                String oldPassword = request.getParameter("oldPassword");
                String newPassword = request.getParameter("newPassword");
                String confirmPassword = request.getParameter("confirmPassword");

                // 验证原密码
                String checkSql = "SELECT * FROM users WHERE id = ? AND password = MD5(?)";
                pstmt = conn.prepareStatement(checkSql);
                pstmt.setInt(1, user.getId());
                pstmt.setString(2, oldPassword);
                ResultSet rs = pstmt.executeQuery();

                if (!rs.next()) {
                    request.setAttribute("error", "原密码错误！");
                } else if (!newPassword.equals(confirmPassword)) {
                    request.setAttribute("error", "两次密码输入不一致！");
                } else {
                    String updateSql = "UPDATE users SET password = MD5(?) WHERE id = ?";
                    pstmt = conn.prepareStatement(updateSql);
                    pstmt.setString(1, newPassword);
                    pstmt.setInt(2, user.getId());
                    pstmt.executeUpdate();
                    request.setAttribute("message", "密码修改成功！");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "操作失败：" + e.getMessage());
        } finally {
            if (pstmt != null) try { pstmt.close(); } catch (SQLException ignored) {}
            if (conn != null) try { conn.close(); } catch (SQLException ignored) {}
        }

        request.getRequestDispatcher("/profile.jsp").forward(request, response);
    }
}
