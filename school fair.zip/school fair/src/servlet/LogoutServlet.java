package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

/**
 * 退出登录Servlet
 */
@WebServlet("/logout")  // <-- 关键：映射到 /logout 路径
public class LogoutServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1. 获取当前Session（如果存在）
        HttpSession session = request.getSession(false);

        if (session != null) {
            // 2. 销毁Session（清除所有用户登录信息）
            session.invalidate();
        }

        // 3. 清除"记住我"Cookie
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("username".equals(cookie.getName())) {
                    cookie.setMaxAge(0); // 立即过期
                    cookie.setPath(request.getContextPath());
                    response.addCookie(cookie);
                    break;
                }
            }
        }

        // 4. 重定向到登录页面
        response.sendRedirect("login.jsp");
    }
}
