package servlet;

import bean.User;
import utils.MyUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

/**
 * 登录验证Servlet
 * 处理用户登录请求，验证身份并创建Session
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1. 获取请求参数
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String rememberMe = request.getParameter("rememberMe");

        // 2. 参数校验
        if (username == null || password == null || username.trim().isEmpty()) {
            request.setAttribute("error", "用户名和密码不能为空！");
            request.getRequestDispatcher("/login.jsp").forward(request, response);
            return;
        }

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            // 3. 连接数据库验证用户
            conn = MyUtil.getConnection();
            String sql = "SELECT id, username, email FROM users WHERE username = ? AND password = MD5(?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                // 4. 登录成功：创建User对象
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setEmail(rs.getString("email"));

                // 5. 创建Session并保存用户信息
                HttpSession session = request.getSession();
                session.setAttribute("user", user);
                session.setMaxInactiveInterval(30 * 60); // 30分钟过期

                // 6. 处理"记住我"功能（Cookie）
                if ("on".equals(rememberMe)) {
                    Cookie usernameCookie = new Cookie("username", username);
                    usernameCookie.setMaxAge(7 * 24 * 60 * 60); // 7天
                    usernameCookie.setPath(request.getContextPath());
                    response.addCookie(usernameCookie);
                } else {
                    // 如果取消勾选，删除Cookie
                    Cookie[] cookies = request.getCookies();
                    if (cookies != null) {
                        for (Cookie cookie : cookies) {
                            if ("username".equals(cookie.getName())) {
                                cookie.setMaxAge(0);
                                cookie.setPath(request.getContextPath());
                                response.addCookie(cookie);
                                break;
                            }
                        }
                    }
                }

                // 7. 重定向到首页或原始请求页面
                String redirect = request.getParameter("redirect");
                if (redirect != null && !redirect.isEmpty()) {
                    response.sendRedirect(redirect);
                } else {
                    response.sendRedirect("index.jsp");
                }

            } else {
                // 8. 登录失败：返回错误信息
                request.setAttribute("error", "用户名或密码错误！");
                request.getRequestDispatcher("/login.jsp").forward(request, response);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "系统错误：" + e.getMessage());
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        } finally {
            // 9. 关闭数据库资源
            MyUtil.close(conn, pstmt, rs);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // 防止直接访问/login，重定向到登录页面
        response.sendRedirect("login.jsp");
    }
}
