package servlet;

import bean.CartItem;
import utils.MyUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * 购物车Servlet
 * 处理所有购物车相关操作
 */
@WebServlet("/cart")
public class CartServlet extends HttpServlet {

    // 模拟用户ID（实际应从Session获取登录用户）
    private static final int MOCK_USER_ID = 1;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) action = "view";

        try {
            switch (action) {
                case "add":
                    addToCart(request, response);
                    break;
                case "update":
                    updateQuantity(request, response);
                    break;
                case "delete":
                    deleteItem(request, response);
                    break;
                case "checkout":
                    checkout(request, response);
                    break;
                case "confirm":
                    confirmOrder(request, response);
                    break;
                default:
                    viewCart(request, response);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("❌ 操作失败: " + e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    /**
     * 1. 添加到购物车
     */
    private void addToCart(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int productId = Integer.parseInt(request.getParameter("productId"));
        String productName = request.getParameter("productName");
        double price = Double.parseDouble(request.getParameter("price"));
        String imageUrl = request.getParameter("imageUrl");
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = MyUtil.getConnection();

            // 检查是否已存在（使用INSERT...ON DUPLICATE KEY UPDATE）
            String sql = "INSERT INTO cart (user_id, product_id, product_name, price, quantity, image_url) " +
                    "VALUES (?, ?, ?, ?, ?, ?) " +
                    "ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)";

            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, MOCK_USER_ID);
            pstmt.setInt(2, productId);
            pstmt.setString(3, productName);
            pstmt.setDouble(4, price);
            pstmt.setInt(5, quantity);
            pstmt.setString(6, imageUrl);

            pstmt.executeUpdate();

            // 添加成功后跳转到购物车页面
            response.sendRedirect("cart?action=view");

        } finally {
            MyUtil.close(conn, pstmt, null);
        }
    }

    /**
     * 2. 查看购物车
     */
    private void viewCart(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<CartItem> cartItems = new ArrayList<>();

        try {
            conn = MyUtil.getConnection();
            String sql = "SELECT * FROM cart WHERE user_id = ? ORDER BY created_at DESC";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, MOCK_USER_ID);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                CartItem item = new CartItem();
                item.setId(rs.getInt("id"));
                item.setUserId(rs.getInt("user_id"));
                item.setProductId(rs.getInt("product_id"));
                item.setProductName(rs.getString("product_name"));
                item.setPrice(rs.getDouble("price"));
                item.setQuantity(rs.getInt("quantity"));
                item.setImageUrl(rs.getString("image_url"));
                cartItems.add(item);
            }

            request.setAttribute("cartItems", cartItems);
            request.getRequestDispatcher("/cart.jsp").forward(request, response);

        } finally {
            MyUtil.close(conn, pstmt, rs);
        }
    }

    /**
     * 3. 更新商品数量
     */
    private void updateQuantity(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int cartId = Integer.parseInt(request.getParameter("id"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = MyUtil.getConnection();
            String sql = "UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, quantity);
            pstmt.setInt(2, cartId);
            pstmt.setInt(3, MOCK_USER_ID);
            pstmt.executeUpdate();

            response.sendRedirect("cart?action=view");
        } finally {
            MyUtil.close(conn, pstmt, null);
        }
    }

    /**
     * 4. 删除商品
     */
    private void deleteItem(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int cartId = Integer.parseInt(request.getParameter("id"));

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = MyUtil.getConnection();
            String sql = "DELETE FROM cart WHERE id = ? AND user_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, cartId);
            pstmt.setInt(2, MOCK_USER_ID);
            pstmt.executeUpdate();

            response.sendRedirect("cart?action=view");
        } finally {
            MyUtil.close(conn, pstmt, null);
        }
    }
    /**
     * 5. 结算页面
     */
    private void checkout(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<CartItem> cartItems = new ArrayList<>();

        try {
            conn = MyUtil.getConnection();
            String sql = "SELECT * FROM cart WHERE user_id = ? ORDER BY created_at DESC";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, MOCK_USER_ID);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                CartItem item = new CartItem();
                item.setId(rs.getInt("id"));
                item.setUserId(rs.getInt("user_id"));
                item.setProductId(rs.getInt("product_id"));
                item.setProductName(rs.getString("product_name"));
                item.setPrice(rs.getDouble("price"));
                item.setQuantity(rs.getInt("quantity"));
                item.setImageUrl(rs.getString("image_url"));
                cartItems.add(item);
            }

            request.setAttribute("cartItems", cartItems);
            // ✅ 关键修改：转发到结算页面
            request.getRequestDispatcher("/checkout.jsp").forward(request, response);

        } finally {
            MyUtil.close(conn, pstmt, rs);
        }
    }

    /**
     * 6. 确认订单（清空购物车）
     */
    private void confirmOrder(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = MyUtil.getConnection();
            // 清空用户购物车
            String sql = "DELETE FROM cart WHERE user_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, MOCK_USER_ID);
            pstmt.executeUpdate();

            // 跳转到成功页面
            response.sendRedirect("success.jsp");
        } finally {
            MyUtil.close(conn, pstmt, null);
        }
    }
}
