package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import utils.MyUtil;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDateTime;

@WebServlet("/productServlet")
@MultipartConfig(
        maxFileSize = 1024 * 1024 * 5,      // 单个文件最大5MB
        maxRequestSize = 1024 * 1024 * 10   // 整个请求最大10MB
)
public class ProductServlet extends HttpServlet {
    public static final String fileDirName = "upload/product";

    /**
     * Servlet初始化时测试数据库连接（重要！）
     */
    @Override
    public void init() throws ServletException {
        System.out.println("=== ProductServlet初始化开始 ===");
        boolean isConnected = MyUtil.testConnection();
        if (!isConnected) {
            System.err.println("⚠️ 警告：数据库连接失败！请检查MyUtil中的URL、用户名、密码是否正确");
            System.err.println("⚠️ 确保TestDB.java能成功运行后再启动Servlet");
        } else {
            System.out.println("✅ 数据库连接正常，Servlet启动成功！");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if ("list".equals(action)) {
            listProducts(req, resp);
        } else {
            // 默认转发到商品列表页面
            req.getRequestDispatcher("/products.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String action = req.getParameter("action");

        if ("insert".equals(action)) {
            insertProduct(req, resp);
        } else if ("delete".equals(action)) {
            deleteProduct(req, resp);
        } else {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "无效的操作");
        }
    }

    /**
     * 添加商品（含文件上传和数据库插入）
     */
    private void insertProduct(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // 1. 获取表单数据
            String productName = req.getParameter("productName");
            String description = req.getParameter("description");
            String priceStr = req.getParameter("price");
            String classify = req.getParameter("classify");
            String stockStr = req.getParameter("stock");
            String sellerIdStr = req.getParameter("sellerId");

            // 2. 数据验证
            if (productName == null || productName.trim().isEmpty()) {
                resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "商品名称不能为空");
                return;
            }

            BigDecimal price = new BigDecimal(priceStr != null ? priceStr : "0");
            int stock = Integer.parseInt(stockStr != null ? stockStr : "0");
            int sellerId = Integer.parseInt(sellerIdStr != null ? sellerIdStr : "1");

            // 3. 处理文件上传
            Part imagePart = req.getPart("image");
            String imageUrl = null;

            if (imagePart != null && imagePart.getSize() > 0) {
                String uploadPath = getServletContext().getRealPath("/" + fileDirName);
                File uploadDir = new File(uploadPath);
                if (!uploadDir.exists()) {
                    uploadDir.mkdirs();
                }

                String originalFileName = MyUtil.getFileName(imagePart);
                String fileExt = originalFileName.substring(originalFileName.lastIndexOf("."));
                String newFileName = System.currentTimeMillis() + "_" + (int)(Math.random() * 1000) + fileExt;

                String filePath = uploadPath + File.separator + newFileName;
                imagePart.write(filePath);

                imageUrl = "/" + fileDirName + "/" + newFileName;
            }

            // 4. 插入数据库
            conn = MyUtil.getConnection();
            String sql = "INSERT INTO product (product_name, description, price, image, classify, stock, seller_id, publish_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(sql);

            pstmt.setString(1, productName);
            pstmt.setString(2, description);
            pstmt.setBigDecimal(3, price);
            pstmt.setString(4, imageUrl);
            pstmt.setString(5, classify != null ? classify : "其他");
            pstmt.setInt(6, stock);
            pstmt.setInt(7, sellerId);
            pstmt.setTimestamp(8, Timestamp.valueOf(LocalDateTime.now()));

            int rows = pstmt.executeUpdate();

            // 5. 根据结果跳转
            if (rows > 0) {
                resp.sendRedirect(req.getContextPath() + "/productServlet?action=list&success=1");
            } else {
                req.setAttribute("error", "商品添加失败");
                req.getRequestDispatcher("/addProduct.jsp").forward(req, resp);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "数据库操作失败: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "参数错误: " + e.getMessage());
        } finally {
            MyUtil.close(conn, pstmt, null);
        }
    }

    /**
     * 查询商品列表
     */
    private void listProducts(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = MyUtil.getConnection();
            String sql = "SELECT p.*, u.username as seller_name FROM product p LEFT JOIN user u ON p.seller_id = u.user_id WHERE p.status = 1 ORDER BY p.publish_time DESC";
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();

            req.setAttribute("products", rs);
            req.getRequestDispatcher("/products.jsp").forward(req, resp);

        } catch (SQLException e) {
            e.printStackTrace();
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "查询失败: " + e.getMessage());
        } finally {
            MyUtil.close(conn, pstmt, rs);
        }
    }

    /**
     * 删除商品（软删除）
     */
    private void deleteProduct(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            String productId = req.getParameter("productId");
            if (productId == null) {
                resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "商品ID不能为空");
                return;
            }

            conn = MyUtil.getConnection();
            String sql = "UPDATE product SET status = 0 WHERE product_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, Integer.parseInt(productId));

            pstmt.executeUpdate();
            resp.sendRedirect(req.getContextPath() + "/productServlet?action=list&deleted=1");

        } catch (SQLException e) {
            e.printStackTrace();
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "删除失败: " + e.getMessage());
        } finally {
            MyUtil.close(conn, pstmt, null);
        }
    }
}
