package bean;

import java.io.Serializable;

/**
 * 购物车项实体类
 */
public class CartItem implements Serializable {
    private int id;
    private int userId;
    private int productId;
    private String productName;
    private double price;
    private int quantity;
    private String imageUrl;

    // 构造函数
    public CartItem() {}

    public CartItem(int userId, int productId, String productName, double price, int quantity, String imageUrl) {
        this.userId = userId;
        this.productId = productId;
        this.productName = productName;
        this.price = price;
        this.quantity = quantity;
        this.imageUrl = imageUrl;
    }

    // Getter 和 Setter 方法
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public int getProductId() { return productId; }
    public void setProductId(int productId) { this.productId = productId; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    /**
     * 计算小计金额
     */
    public double getSubtotal() {
        return price * quantity;
    }
}
